import React from 'react';

const MyComponent = ({text}) => {
    return (
        <div className="horizontal">
            <span>{text}</span>
        </div>
    );
};

export default MyComponent;
