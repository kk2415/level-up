import React from 'react';
import ArticleTable from "./channel/ChannelTable";

const Article = ({info}) => {
    return (
        <>
        </>
    );
};

export default Article;
